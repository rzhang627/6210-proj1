# Memory Coordinator

- Please write your algorithm and logic for the memory coordinator in this readme. 
- Include details about how the algorithm is designed and explain the overall flow of your program.
- Use pseudocode or simple explanations where necessary to make it easy to understand.
- Don't forget to cite any resources that you've used to complete the assignment.
